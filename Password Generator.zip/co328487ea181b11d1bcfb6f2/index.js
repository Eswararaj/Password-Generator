const characters = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9","~","`","!","@","#","$","%","^","&","*","(",")","_","-","+","=","{","[","}","]",",","|",":",";","<",">",".","?",
"/"];

const generate = document.getElementById("generate");
const pass = document.getElementById("pass1");
const pass1 = document.getElementById("pass2");
const setValue = document.getElementById("setvalue1");
const setValue1 = document.getElementById("setvalue2");
let getInput = document.getElementById("getInput");

function renderIs()
{
     let password1 = Math.floor(Math.random(characters)*characters.length);
     return characters[password1]
}
function renderIs1()
{
     let password2 = Math.floor(Math.random(characters)*characters.length);
     return characters[password2]
}


function generatePass(){  
    
    let newGenerate =""
    
    for(let i=0; i<10; i++)
    {
        newGenerate+=renderIs()
    }
    
    return newGenerate;
}

function generatePass1(){  
    
    let newGenerate1 =""
    
    for(let i=0; i<10; i++)
    {
        newGenerate1+=renderIs1()
    }
    
    return newGenerate1;
}

function generat(){
   setValue.innerText = generatePass()
   setValue1.innerText = generatePass1()
}

function myfun(a){
    getInput.value=a.innerText;   
}

